import TradeCard from './TradeCard';
export default TradeCard;
