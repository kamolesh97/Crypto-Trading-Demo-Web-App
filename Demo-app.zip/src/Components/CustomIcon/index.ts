import CustomIcon from './CustomIcon';
export default CustomIcon;
